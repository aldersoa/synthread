import React, { useEffect, useState } from "react";
import { createRoot } from "react-dom/client";
import "./styles.css";

const routes = [
  { path: "/welcome", label: "Welcome" },
  { path: "/connect", label: "Connect" },
  { path: "/weaving", label: "Weaving" },
  { path: "/result", label: "Result" },
  { path: "/translation", label: "Translation" },
  { path: "/share", label: "Share" },
];

const routeIndex = () => Math.max(0, routes.findIndex(({ path }) => path === window.location.pathname));

function go(path) {
  window.history.pushState({}, "", path);
  window.dispatchEvent(new PopStateEvent("popstate"));
}

function Wordmark({ small = false }) {
  return <div className={`wordmark ${small ? "wordmark--small" : ""}`}>synThread</div>;
}

function Textile({ compact = false, animated = false }) {
  return (
    <div className={`textile ${compact ? "textile--compact" : ""} ${animated ? "textile--animated" : ""}`} aria-label="Pastel woven pattern">
      <svg viewBox="0 0 320 360" role="img" aria-hidden="true" preserveAspectRatio="xMidYMid slice">
        <defs>
          <pattern id={`warp-${compact}-${animated}`} width="32" height="32" patternUnits="userSpaceOnUse">
            <rect width="32" height="32" fill="#302b27" />
            <rect x="0" width="7" height="32" fill="#f4b8d0" />
            <rect x="9" width="3" height="32" fill="#7c6fcb" />
            <rect x="15" width="9" height="32" fill="#a8d0f0" />
            <rect x="27" width="3" height="32" fill="#f5e6a8" />
          </pattern>
          <pattern id={`weft-${compact}-${animated}`} width="320" height="48" patternUnits="userSpaceOnUse">
            <rect width="320" height="48" fill="transparent" />
            <rect y="0" width="320" height="6" fill="#a8e6b0" opacity=".92" />
            <rect y="9" width="320" height="3" fill="#2b2622" opacity=".8" />
            <rect y="16" width="320" height="11" fill="#f5e6a8" opacity=".75" />
            <rect y="31" width="320" height="4" fill="#7c6fcb" opacity=".94" />
            <rect y="39" width="320" height="7" fill="#f4b8d0" opacity=".62" />
          </pattern>
          <filter id={`thread-${compact}-${animated}`}>
            <feTurbulence baseFrequency=".8 .04" numOctaves="1" seed="12" type="fractalNoise" result="noise" />
            <feBlend in="SourceGraphic" in2="noise" mode="soft-light" />
          </filter>
        </defs>
        <rect width="320" height="360" fill={`url(#warp-${compact}-${animated})`} />
        <g className="textile-weft" filter={`url(#thread-${compact}-${animated})`}>
          <rect width="320" height="360" fill={`url(#weft-${compact}-${animated})`} />
        </g>
        <g fill="none" strokeLinecap="square" opacity=".82">
          <path d="M-20 68 H104 V88 H216 V68 H340" stroke="#a8e6b0" strokeWidth="6" />
          <path d="M-20 142 H64 V164 H148 V142 H248 V164 H340" stroke="#a8d0f0" strokeWidth="5" />
          <path d="M-20 252 H84 V230 H190 V252 H340" stroke="#f4b8d0" strokeWidth="7" />
          <path d="M-20 316 H42 V300 H132 V316 H226 V300 H340" stroke="#7c6fcb" strokeWidth="4" />
        </g>
        <rect x="1.5" y="1.5" width="317" height="357" fill="none" stroke="#fff" strokeOpacity=".08" strokeWidth="3" />
      </svg>
    </div>
  );
}

function Icon({ name }) {
  const paths = {
    arrow: <><path d="M5 12h14" /><path d="m14 7 5 5-5 5" /></>,
    back: <><path d="M19 12H5" /><path d="m10 7-5 5 5 5" /></>,
    save: <><path d="M6 4h12v16H6z" /><path d="M9 4v5h6V4M9 16h6" /></>,
    share: <><circle cx="18" cy="5" r="2" /><circle cx="6" cy="12" r="2" /><circle cx="18" cy="19" r="2" /><path d="m8 11 8-5M8 13l8 5" /></>,
  };
  return <svg className="icon" viewBox="0 0 24 24" aria-hidden="true">{paths[name]}</svg>;
}

function ScreenShell({ children, next, back, quiet = false }) {
  return (
    <main className={`screen ${quiet ? "screen--quiet" : ""}`}>
      {!quiet && <Wordmark small />}
      {children}
      {(back || next) && (
        <div className="screen-nav">
          {back ? <button className="text-button" onClick={() => go(back)}><Icon name="back" />Back</button> : <span />}
          {next && <button className="text-button" onClick={() => go(next)}>Next<Icon name="arrow" /></button>}
        </div>
      )}
    </main>
  );
}

function Welcome() {
  return (
    <ScreenShell quiet>
      <Wordmark />
      <div className="welcome-copy">
        <p className="eyebrow">Your listening, made tangible</p>
        <h1>What would your taste in music look like worn?</h1>
        <p className="lede">Turn your listening history into a pattern.</p>
        <button className="button button--violet" onClick={() => go("/connect")}>Start <Icon name="arrow" /></button>
      </div>
    </ScreenShell>
  );
}

function Connect() {
  return (
    <ScreenShell back="/welcome">
      <div className="centered-copy">
        <div className="record-mark" aria-hidden="true"><span /></div>
        <p className="eyebrow">One small step</p>
        <h1>Connect your music</h1>
        <p className="lede">synThread uses your listening history to find the rhythms, moods, and eras that make your pattern yours.</p>
        <button className="button button--green" onClick={() => go("/weaving")}>Continue with Spotify <Icon name="arrow" /></button>
        <p className="fine-print">Your data stays private. This prototype uses fictional sample listening results.</p>
      </div>
    </ScreenShell>
  );
}

function Weaving() {
  return (
    <ScreenShell back="/connect" next="/result">
      <div className="weaving-head">
        <p className="eyebrow">Reading the rhythm</p>
        <h1>Weaving your pattern…</h1>
        <p className="lede">Listening across four decades</p>
      </div>
      <div className="loom" aria-label="Pattern weaving animation">
        <Textile animated />
        <div className="loom-bar" />
      </div>
      <div className="progress-label"><span>Composing structure</span><span>72%</span></div>
    </ScreenShell>
  );
}

function Result() {
  return (
    <ScreenShell back="/weaving" next="/share">
      <div className="result-head">
        <p className="eyebrow">Your thread 01</p>
        <h1>Electric nostalgia</h1>
        <p>Built from 5,420 minutes · 7 eras · 48 artists</p>
      </div>
      <Textile />
      <button className="link-action" onClick={() => go("/translation")}>Explore the translation <Icon name="arrow" /></button>
    </ScreenShell>
  );
}

const mappings = [
  ["Tempo", "repeat density"],
  ["Energy", "contrast and scale"],
  ["Valence", "palette warmth"],
  ["Acousticness", "surface texture"],
  ["Era spread", "color and structural distribution"],
];
const artists = ["Talking Heads", "A Tribe Called Quest", "Radiohead", "Daft Punk", "Kendrick Lamar", "Tame Impala", "Khruangbin"];

function Translation() {
  return (
    <ScreenShell back="/result" next="/share">
      <div className="translation-head">
        <p className="eyebrow">Inside the weave</p>
        <h1>Your listening, translated</h1>
        <p className="translation-note">A fictional sample showing how musical qualities shape each thread.</p>
      </div>
      <dl className="mapping-list">
        {mappings.map(([term, value], i) => <div key={term}><dt><span>0{i + 1}</span>{term}</dt><dd>{value}</dd></div>)}
      </dl>
      <div className="artist-cloud">
        <p>Across the eras</p>
        <div>{artists.map((artist) => <span key={artist}>{artist}</span>)}</div>
      </div>
    </ScreenShell>
  );
}

function Share() {
  const [toast, setToast] = useState("");
  const notify = (message) => {
    setToast(message);
    window.setTimeout(() => setToast(""), 2200);
  };
  return (
    <ScreenShell back="/result">
      <div className="share-head">
        <p className="eyebrow">Electric nostalgia</p>
        <h1>Take your thread with you</h1>
      </div>
      <div className="poster">
        <Textile compact />
        <div className="poster-caption"><Wordmark small /><span>Listening pattern · 01</span></div>
      </div>
      <div className="share-actions">
        <button className="button button--violet" onClick={() => notify("Pattern saved")}>Save pattern <Icon name="save" /></button>
        <button className="button button--outline" onClick={() => notify("Share link copied")}>Share <Icon name="share" /></button>
      </div>
      <div className={`toast ${toast ? "toast--show" : ""}`} role="status">{toast}<span>✓</span></div>
    </ScreenShell>
  );
}

const screens = { "/welcome": Welcome, "/connect": Connect, "/weaving": Weaving, "/result": Result, "/translation": Translation, "/share": Share };

function App() {
  const [path, setPath] = useState(window.location.pathname);
  const [screenshotMode, setScreenshotMode] = useState(new URLSearchParams(window.location.search).has("screenshot"));
  useEffect(() => {
    if (!screens[window.location.pathname]) go("/welcome");
    const sync = () => setPath(window.location.pathname);
    window.addEventListener("popstate", sync);
    return () => window.removeEventListener("popstate", sync);
  }, []);
  const Screen = screens[path] || Welcome;
  return (
    <div className={`prototype ${screenshotMode ? "prototype--screenshot" : ""}`}>
      <aside className="desktop-controls" aria-label="Prototype controls">
        <div className="control-brand"><Wordmark small /><span>Screen preview</span></div>
        <nav>
          {routes.map((route, i) => <button className={path === route.path ? "active" : ""} onClick={() => go(route.path)} key={route.path}><span>0{i + 1}</span>{route.label}</button>)}
        </nav>
        <button className="screenshot-toggle" onClick={() => setScreenshotMode(true)}><span className="focus-icon" />Screenshot mode</button>
      </aside>
      <section className="phone-wrap" aria-label={`${routes[routeIndex()].label} mobile screen`}>
        <div className="phone"><Screen /></div>
      </section>
      {screenshotMode && <button className="exit-screenshot" onClick={() => setScreenshotMode(false)}>Exit screenshot mode</button>}
    </div>
  );
}

createRoot(document.getElementById("root")).render(<App />);

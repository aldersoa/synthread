# synThread prototype

A screenshot-ready mobile web prototype that turns fictional listening history into an original woven pattern. All data and artwork are local and deterministic.

## Run

```bash
npm install
npm run dev
```

Open `http://localhost:5173/welcome`.

## Routes

- `/welcome`
- `/connect`
- `/weaving`
- `/result`
- `/translation`
- `/share`

Each route can be opened or refreshed directly in the Vite development server.

## Screenshots

Use the desktop screen list to move between views. Select **Screenshot mode** below the list to hide the desktop controls while keeping the phone frame visible. You can also add `?screenshot` to any route URL.

For consistent captures, use a desktop browser viewport of at least `900 × 930` pixels. The phone display is designed at `390 × 844` pixels.

## Production preview

```bash
npm run build
npm run preview
```
